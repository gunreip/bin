#!/usr/bin/env bash
set -euo pipefail

SCRIPT_NAME="git_repo_clean_old_remote.sh"
SCRIPT_VERSION="v0.1.1"

usage() {
  cat <<EOF
${SCRIPT_NAME} ${SCRIPT_VERSION}
Clean up or modify a Git remote safely.

Usage:
  ${SCRIPT_NAME} [-p <project_path>] [--remote <name>] [--remove] [--rename <new_name>] [--url <new_url>] [--dry-run] [--version]

Options:
  -p <path>         Project repo path (default: current directory)
  --remote <name>   Remote name to operate on (default: origin)
  --remove          Remove the remote
  --rename <name>   Rename the remote to <name>
  --url <url>       Set new URL for the remote
  --dry-run         Show actions without executing
  --version         Print version and exit
  -h, --help        Show this help
EOF
}

PROJECT_PATH=""
REMOTE="origin"
REMOVE=false
RENAME_TO=""
NEW_URL=""
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    -p) PROJECT_PATH="${2:-}"; shift 2;;
    --remote) REMOTE="${2:-}"; shift 2;;
    --remove) REMOVE=true; shift;;
    --rename) RENAME_TO="${2:-}"; shift 2;;
    --url) NEW_URL="${2:-}"; shift 2;;
    --dry-run) DRY_RUN=true; shift;;
    --version) echo "${SCRIPT_NAME} ${SCRIPT_VERSION}"; exit 0;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown argument: $1" >&2; usage; exit 2;;
  esac
done

if [[ -z "${PROJECT_PATH}" ]]; then PROJECT_PATH="$(pwd)"; fi
if [[ ! -d "${PROJECT_PATH}" ]]; then
  echo "Project path not found: ${PROJECT_PATH}" >&2
  exit 2
fi

cd "${PROJECT_PATH}"

if [[ ! -d ".git" ]]; then
  echo "Not a Git repository: ${PROJECT_PATH}" >&2
  exit 2
fi

run() {
  if $DRY_RUN; then
    printf '[dry-run] %s\n' "$*"
  else
    eval "$@"
  fi
}

# Ensure remote exists (except when adding via --url with non-existing remote? we assume it should exist)
if ! git remote | grep -qx "${REMOTE}"; then
  echo "Remote '${REMOTE}' not found." >&2
  exit 2
fi

# Show current state (for context)
CUR_URL="$(git remote get-url "${REMOTE}" 2>/dev/null || true)"
printf 'Current remote: %s -> %s\n' "${REMOTE}" "${CUR_URL:-<no-url>}"

# Perform actions
if $REMOVE; then
  run "git remote remove "${REMOTE}""
  printf 'Removed remote: %s\n' "${REMOTE}"
  exit 0
fi

if [[ -n "${RENAME_TO}" ]]; then
  run "git remote rename "${REMOTE}" "${RENAME_TO}""
  printf 'Renamed remote: %s -> %s\n' "${REMOTE}" "${RENAME_TO}"
  REMOTE="${RENAME_TO}"
fi

if [[ -n "${NEW_URL}" ]]; then
  run "git remote set-url "${REMOTE}" "${NEW_URL}""
  printf 'Updated URL for %s -> %s\n' "${REMOTE}" "${NEW_URL}"
fi

printf 'Done.\n'
