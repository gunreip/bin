#!/usr/bin/env bash
SCRIPT_VERSION="v0.2.0"
set -euo pipefail

DRY=0; STAGED=0; AGAINST=""; FORMAT="summary"; MAX=5

print_help(){ cat <<'HLP'
git_diff_report.sh — schreibt Diff-Report als Markdown nach .wiki/git_diffs/ (nur im Projekt-WD)

USAGE
  git_diff_report.sh [OPTS]

OPTIONEN
  --against <ref>     Vergleichs-Ref (Default: Upstream, sonst origin/<branch>, sonst HEAD~1)
  --staged            Nur staged Änderungen
  --format <f>        summary | name-only | full   (Default: summary)
  --max <N>           Max. Anzahl Reports behalten (Default: 5)
  --dry-run           Nur anzeigen, was geschrieben würde
  --version           Skriptversion
  -h, --help          Hilfe

HINWEIS
  • Gatekeeper: Skript muss im Projekt-WD mit .env laufen.
HLP
}

usage(){ print_help; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --against) AGAINST="$2"; shift 2;;
    --staged) STAGED=1; shift;;
    --format) FORMAT="$2"; shift 2;;
    --max) MAX="$2"; shift 2;;
    --dry-run) DRY=1; shift;;
    --version) printf '%s\n' "$SCRIPT_VERSION"; exit 0;;
    -h|--help) print_help; exit 0;;
    *) printf 'Unbekannter Parameter: %s\n' "$1" >&2; usage;;
  esac
done

[[ -f .env ]] || { echo 'Fehler: .env fehlt. Skript nur im Projektordner ausführen.' >&2; exit 2; }
command -v git >/dev/null || { echo 'Fehler: git nicht gefunden.' >&2; exit 3; }

branch="$(git rev-parse --abbrev-ref HEAD)"
if [[ -z "$AGAINST" ]]; then
  if git rev-parse --abbrev-ref --symbolic-full-name '@{u}' >/dev/null 2>&1; then AGAINST='@{u}'
  elif git rev-parse "origin/${branch}" >/dev/null 2>&1; then AGAINST="origin/${branch}"
  else AGAINST="HEAD~1"; fi
fi

outdir=".wiki/git_diffs"; mkdir -p "$outdir"
ts="$(date +%Y%m%d_%H%M%S)"; outfile="${outdir}/diff_${ts}.md"

run(){ if [[ "$DRY" -eq 1 ]]; then echo "[DRY] $*"; else eval "$@"; fi }

case "$FORMAT" in
  summary)  DIFF_CMD1="git diff --stat ${AGAINST} --"; DIFF_CMD2=$([[ "$STAGED" -eq 1 ]] && echo "git diff --cached ${AGAINST}" || echo "git diff ${AGAINST}") ;;
  name-only)DIFF_CMD1="git diff --name-status ${AGAINST} --"; DIFF_CMD2=$([[ "$STAGED" -eq 1 ]] && echo "git diff --cached --name-only ${AGAINST}" || echo "git diff --name-only ${AGAINST}") ;;
  full)     DIFF_CMD1="git diff --stat ${AGAINST} --"; DIFF_CMD2=$([[ "$STAGED" -eq 1 ]] && echo "git diff --cached ${AGAINST}" || echo "git diff ${AGAINST}") ;;
  *) echo 'Fehler: Unbekanntes Format.' >&2; exit 4;;
esac

{
  echo "# Diff-Report"
  echo "- Branch: ${branch}"
  echo "- Gegen:  ${AGAINST}"
  echo "- Staged: $([[ $STAGED -eq 1 ]] && echo yes || echo no)"
  echo "- Format: ${FORMAT}"
  echo "- Zeit:   $(date '+%Y-%m-%d %H:%M')"
  echo
  echo "## Zusammenfassung"; eval "$DIFF_CMD1"
  echo
  echo "## Änderungen";     eval "$DIFF_CMD2"
} > "$outfile"

if [[ "$DRY" -eq 1 ]]; then
  echo "[DRY] würde schreiben: $outfile"
else
  echo "OK: $outfile"
fi

# Housekeeping
cnt=0
for f in $(ls -t "$outdir"/diff_*.md 2>/dev/null); do
  cnt=$((cnt+1)); if (( cnt > MAX )); then run "rm -f '$f'"; fi
done
