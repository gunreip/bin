    #!/bin/bash
    set -e
    SCRIPT_VERSION="v0.1.2"
    PROJECT_PATH=""
    BRANCH="main"
    REMOTE_URL=""
    REINIT=false
    NO_PUSH=false
    DRY_RUN=false
    print_version() { echo "git_repo_setup.sh $SCRIPT_VERSION"; exit 0; }
    die() { echo "Error: $*" >&2; exit 1; }
    run() { if $DRY_RUN; then echo "[dry-run] $*"; else eval "$@"; fi }
    while [[ $# -gt 0 ]]; do
      case "$1" in
        -p|--path) PROJECT_PATH="$2"; shift 2;;
        -r|--remote) REMOTE_URL="$2"; shift 2;;
        --branch) BRANCH="$2"; shift 2;;
        --reinit) REINIT=true; shift;;
        --no-push) NO_PUSH=true; shift;;
        --dry-run) DRY_RUN=true; shift;;
        --version) print_version;;
        -h|--help)
          cat <<EOF
Usage: git_repo_setup.sh [-p <project_path>] [-r <remote_url>] [--branch <name>] [--reinit] [--no-push] [--dry-run]
Defaults: branch=main, path=$PWD
EOF
          exit 0;;
        *) die "Unknown argument: $1";;
      esac
    done
    if [[ -z "$PROJECT_PATH" ]]; then PROJECT_PATH="$(pwd)"; fi
    [[ -d "$PROJECT_PATH" ]] || die "Project path not found: $PROJECT_PATH"
    cd "$PROJECT_PATH"
    if $REINIT && [[ -d ".git" ]]; then run "rm -rf .git"; fi
    if [[ ! -d ".git" ]]; then run "git init -b "$BRANCH""
    else CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo '')"
         if [[ "$CURRENT_BRANCH" != "$BRANCH" && -n "$CURRENT_BRANCH" ]]; then run "git checkout -B "$BRANCH""; fi
    fi
    run "git add -A"
    if $DRY_RUN; then echo "[dry-run] git commit -m "chore: initial commit" (only if staged changes exist)"
    else if ! git diff --cached --quiet; then git commit -m "chore: initial commit"; fi
    fi
    if [[ -n "$REMOTE_URL" ]]; then
      if git remote get-url origin >/dev/null 2>&1; then run "git remote set-url origin "$REMOTE_URL""
      else run "git remote add origin "$REMOTE_URL""; fi
    fi
    if ! $NO_PUSH && [[ -n "$REMOTE_URL" ]]; then run "git push -u origin "$BRANCH""; fi
    if $DRY_RUN; then echo "Done."; fi
