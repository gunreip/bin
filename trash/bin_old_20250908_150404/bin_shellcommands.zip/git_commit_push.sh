#!/usr/bin/env bash
SCRIPT_VERSION="v0.2.0"
set -euo pipefail

REMOTE="origin"; BRANCH=""; DRY=0; AMEND=0; NO_VERIFY=0; ADD_ALL=0; ADD_PATHS=""; MSG=""

print_help(){ cat <<'HLP'
git_commit_push.sh — staged Änderungen committen & pushen (nur im Projekt-Working-Dir)

USAGE
  git_commit_push.sh [OPTS]

OPTIONEN
  --all              Alle Änderungen stagen (git add -A)
  --add "<paths>"    Bestimmte Dateien/Pattern stagen (z. B. "app/ routes/*.php")
  -m "<message>"     Commit-Message (Pflicht, außer --amend)
  --amend            Letzten Commit ändern (mit/ohne neue Message)
  --no-verify        Git-Hooks beim Commit/Push überspringen
  --remote <name>    Remote-Name (Default: origin)
  --branch <name>    Branch (Default: aktueller Branch)
  --dry-run          Nur anzeigen, was ausgeführt würde
  --version          Skriptversion
  -h, --help         Diese Hilfe

HINWEIS
  • Gatekeeper: Skript muss im Projekt-WD mit .env laufen.
HLP
}

usage(){ print_help; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --remote) REMOTE="$2"; shift 2;;
    --branch) BRANCH="$2"; shift 2;;
    --all) ADD_ALL=1; shift;;
    --add) ADD_PATHS="$2"; shift 2;;
    -m) MSG="$2"; shift 2;;
    --amend) AMEND=1; shift;;
    --no-verify) NO_VERIFY=1; shift;;
    --dry-run) DRY=1; shift;;
    --version) printf '%s\n' "$SCRIPT_VERSION"; exit 0;;
    -h|--help) print_help; exit 0;;
    *) printf 'Unbekannter Parameter: %s\n' "$1" >&2; usage;;
  esac
done

[[ -f .env ]] || { echo 'Fehler: .env fehlt. Skript nur im Projektordner ausführen.' >&2; exit 2; }
command -v git >/dev/null || { echo 'Fehler: git nicht gefunden.' >&2; exit 3; }

run(){ if [[ "$DRY" -eq 1 ]]; then echo "[DRY] $*"; else eval "$@"; fi }

# Staging
if [[ "$ADD_ALL" -eq 1 ]]; then run "git add -A"; fi
if [[ -n "$ADD_PATHS" ]]; then run "git add -- $ADD_PATHS"; fi

# Branch
if [[ -z "${BRANCH:-}" ]]; then BRANCH="$(git rev-parse --abbrev-ref HEAD)"; fi

# Commit
if ! git diff --quiet --cached; then
  if [[ "$AMEND" -eq 1 ]]; then
    if [[ -n "$MSG" ]]; then run "git commit --amend -m \"$(printf '%s' "$MSG")\" $([[ $NO_VERIFY -eq 1 ]] && printf -- '--no-verify')"
    else run "git commit --amend --no-edit $([[ $NO_VERIFY -eq 1 ]] && printf -- '--no-verify')"; fi
  else
    [[ -n "$MSG" ]] || { echo 'Fehler: Commit-Message fehlt (verwende -m "...").' >&2; exit 4; }
    run "git commit -m \"$(printf '%s' "$MSG")\" $([[ $NO_VERIFY -eq 1 ]] && printf -- '--no-verify')"
  fi
else
  if [[ "$AMEND" -eq 1 ]]; then
    if [[ -n "$MSG" ]]; then run "git commit --amend -m \"$(printf '%s' "$MSG")\" $([[ $NO_VERIFY -eq 1 ]] && printf -- '--no-verify')"
    else run "git commit --amend --no-edit $([[ $NO_VERIFY -eq 1 ]] && printf -- '--no-verify')"; fi
  else
    echo 'Hinweis: Keine staged changes, überspringe Commit.' >&2
  fi
fi

# Push
if git remote get-url "$REMOTE" >/dev/null 2>&1; then
  run "git push -u \"$REMOTE\" \"${BRANCH:-$(git rev-parse --abbrev-ref HEAD)}\""
else
  echo "Fehler: Remote \"$REMOTE\" existiert nicht." >&2; exit 5
fi
