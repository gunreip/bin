#!/usr/bin/env bash
# git_status_short.sh — kompakter Git-Status mit optionalem Datei-Output
# Version: v0.4.2  (defensiv, exit immer 0)
# Hinweis: im Projekt-Root mit .env ausführen
set -uo pipefail

VERSION="v0.4.2"
DO_OUT=0
FORMAT="txt"
MAX=10

print_help(){ cat <<'HLP'
git_status_short — kompakter Git-Status
USAGE
  git_status_short [--out] [--format txt|md] [--max N] [--help] [--version]
HLP
}

# --- Args ---
while [[ $# -gt 0 ]]; do
  case "$1" in
    --out) DO_OUT=1; shift;;
    --format) FORMAT="${2:-txt}"; shift 2;;
    --max) MAX="${2:-10}"; shift 2;;
    --version) echo "$VERSION"; exit 0;;
    -h|--help) print_help; exit 0;;
    *) echo "Unbekannter Parameter: $1" >&2; print_help; exit 0;;
  esac
done

# --- Gatekeeper (nur Hinweis, kein harter Abbruch) ---
if [[ ! -f .env ]]; then
  echo "Hinweis: .env nicht gefunden – weiter mit Best-Effort." >&2
fi
command -v git >/dev/null 2>&1 || { echo "Hinweis: git fehlt." >&2; echo "git fehlt"; exit 0; }

# --- Daten sammeln (alles best-effort) ---
branch="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "-")"
commit="$(git rev-parse --short HEAD 2>/dev/null || echo "-")"
upstream="$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null || echo "-")"

ahead="0"; behind="0"
if [[ "$upstream" != "-" ]]; then
  read -r behind ahead < <(git rev-list --left-right --count "${upstream}...HEAD" 2>/dev/null || echo "0 0")
fi

stashes="$(git stash list 2>/dev/null | wc -l | tr -d ' ' || echo 0)"
last_tag="$(git describe --tags --abbrev=0 2>/dev/null || echo "-")"
remote="$(git remote get-url origin 2>/dev/null || echo "-")"

# staged
mapfile -t staged_arr < <(git diff --cached --name-status 2>/dev/null || true)
stA=0; stM=0; stD=0; stR=0
for l in "${staged_arr[@]}"; do
  c="${l%%$'\t'*}"
  case "$c" in
    A*) ((stA++));;
    M*) ((stM++));;
    D*) ((stD++));;
    R*|C*) ((stR++));;
  esac
done
staged_total=$((stA+stM+stD+stR))

# unstaged
mapfile -t unstaged_arr < <(git diff --name-status 2>/dev/null || true)
unM=0; unD=0; unR=0
for l in "${unstaged_arr[@]}"; do
  c="${l%%$'\t'*}"
  case "$c" in
    M*) ((unM++));;
    D*) ((unD++));;
    R*|C*) ((unR++));;
  esac
done
unstaged_total=$((unM+unD+unR))

untracked=$(git ls-files --others --exclude-standard 2>/dev/null | wc -l | tr -d ' ' || echo 0)
conflicts=$(git diff --name-only --diff-filter=U 2>/dev/null | wc -l | tr -d ' ' || echo 0)

# --- Ausgabe ---
if [[ "$FORMAT" == "md" ]]; then
  out="$(
    printf "## Git Status (kurz)\n"
    printf "- branch: %s\n" "$branch"
    printf "- commit: %s\n" "$commit"
    printf "- upstream: %s\n" "$upstream"
    printf "- ahead/behind: %s/%s\n" "$ahead" "$behind"
    printf "- stashes: %s\n" "$stashes"
    printf "- last tag: %s\n" "$last_tag"
    printf "- remote: %s\n" "$remote"
    printf "- staged: %s (A:%s M:%s D:%s R:%s)\n" "$staged_total" "$stA" "$stM" "$stD" "$stR"
    printf "- unstaged: %s (M:%s D:%s R:%s)\n" "$unstaged_total" "$unM" "$unD" "$unR"
    printf "- untracked: %s\n" "$untracked"
    printf "- conflicts: %s\n" "$conflicts"
  )"
else
  out="$(
    printf "branch:     %s\n" "$branch"
    printf "commit:     %s\n" "$commit"
    printf "upstream:   %s\n" "$upstream"
    printf "ahead/behind: %s/%s\n" "$ahead" "$behind"
    printf "stashes:    %s\n" "$stashes"
    printf "last tag:   %s\n" "$last_tag"
    printf "remote:     %s\n" "$remote"
    printf "staged:     %s (A:%s M:%s D:%s R:%s)\n" "$staged_total" "$stA" "$stM" "$stD" "$stR"
    printf "unstaged:   %s (M:%s D:%s R:%s)\n" "$unstaged_total" "$unM" "$unD" "$unR"
    printf "untracked:  %s\n" "$untracked"
    printf "conflicts:  %s\n" "$conflicts"
  )"
fi

# Terminal
printf "%s\n" "$out"

# Datei-Output + Housekeeping (best-effort)
if (( DO_OUT == 1 )); then
  outdir=".wiki/git_status"; ts="$(date +%Y%m%d_%H%M%S)"; mkdir -p "$outdir" || true
  ext="$FORMAT"; [[ "$ext" != "md" ]] && ext="txt"
  file="${outdir}/status_${ts}.${ext}"
  printf "%s\n" "$out" > "$file" 2>/dev/null || true
  echo "OK: ${file}"
  mapfile -t files < <(ls -t "$outdir"/status_*.${ext} 2>/dev/null || true)
  cnt=0
  for f in "${files[@]}"; do
    cnt=$((cnt+1))
    (( cnt > MAX )) && rm -f -- "$f" || true
  done
fi

# immer "grün" beenden
exit 0
