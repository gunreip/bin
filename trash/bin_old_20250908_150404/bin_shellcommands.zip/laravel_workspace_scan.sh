#!/usr/bin/env bash
# laravel_workspace_scan.sh v0.4.4
# Generates a Markdown snapshot of a Laravel project workspace.

set -euo pipefail

SCRIPT_VERSION="v0.4.4"

PROJECT_PATH=""
STRUCTURE_MODE="flat"   # flat | deep

print_version() {
  printf '%s\n' "laravel_workspace_scan.sh v0.4.4"
}

# --- arg parsing ---
while [[ $# -gt 0 ]]; do
  case "$1" in
    -p)
      [[ $# -ge 2 ]] || { printf '%s\n' "ERROR: -p requires a path" >&2; exit 1; }
      PROJECT_PATH="$2"; shift 2;;
    --structure=deep) STRUCTURE_MODE="deep"; shift;;
    --structure=flat) STRUCTURE_MODE="flat"; shift;;
    --structure)
      [[ $# -ge 2 ]] || { printf '%s\n' "ERROR: --structure requires a value (flat|deep)" >&2; exit 1; }
      case "$2" in
        deep|flat) STRUCTURE_MODE="$2"; shift 2;;
        *) printf '%s\n' "ERROR: --structure must be flat or deep" >&2; exit 1;;
      esac;;
    --version|-V) print_version; exit 0;;
    *)
      printf '%s\n' "ERROR: Unknown parameter: $1" >&2; exit 1;;
  esac
done

if [[ -z "${PROJECT_PATH}" ]]; then
  PROJECT_PATH="$(pwd)"
fi

# Gatekeeper: must be a Laravel project root (.env present)
if [[ ! -f "${PROJECT_PATH}/.env" ]]; then
  printf '%s\n' "ERROR: Not a Laravel project folder (.env missing): $PROJECT_PATH" >&2
  exit 2
fi

# Prepare output dir & filename
SCAN_DIR="${PROJECT_PATH}/.wiki/project_scans"
mkdir -p "${SCAN_DIR}"
TIMESTAMP="$(date +"%Y%m%d_%H%M")"
if [[ "${STRUCTURE_MODE}" == "deep" ]]; then
  SCAN_FILE="${SCAN_DIR}/project_scan_deep_${TIMESTAMP}.md"
else
  SCAN_FILE="${SCAN_DIR}/project_scan_${TIMESTAMP}.md"
fi

# util: safe append single line to SCAN_FILE
line() {
  # usage: line "text"
  printf '%s\n' "$1" >> "${SCAN_FILE}"
}

# util: code fences
open_fence() {
  line '```text'
}
close_fence() {
  line '```'
}

PROJECT_NAME="$(basename "${PROJECT_PATH}")"
NOW_HUMAN="$(date +"%Y-%m-%d %H:%M")"

# --- header ---
: > "${SCAN_FILE}"  # truncate
line "# Laravel Projekt-Scan – ${SCRIPT_VERSION}"
line ""
line "- Projekt: ${PROJECT_NAME}"
line "- Projektpfad: \`${PROJECT_PATH}\`"
line "- Erstellt am: ${NOW_HUMAN}"
line "- Version: ${SCRIPT_VERSION}"
line ""

# --- project structure (Explorer style) ---
line "## 📁 Projektstruktur"
line ""
open_fence

# Build lists: dirs first (A–Z), then files (A–Z)
# Exclude .git folder from listing
mapfile -t DIRS < <(find "${PROJECT_PATH}" -maxdepth 1 -mindepth 1 -type d ! -name ".git" -printf '%f\n' | LC_ALL=C sort)
mapfile -t FILES < <(find "${PROJECT_PATH}" -maxdepth 1 -mindepth 1 -type f -printf '%f\n' | LC_ALL=C sort)

# Print root
line "📁 ${PROJECT_NAME}"

total=$(( ${#DIRS[@]} + ${#FILES[@]} ))
index=0

# helper to compute prefix continuation
# args: is_last (0/1)
cont_prefix() {
  if [[ "$1" -eq 1 ]]; then printf '%s' "    "; else printf '%s' "│   "; fi
}

# print a single entry line with tree connector
# args: connector, display
entry() {
  local connector="$1"; shift
  local display="$1"
  line "${connector} ${display}"
}

# Print directories first
for name in "${DIRS[@]}"; do
  index=$((index+1))
  if [[ $index -eq $total ]]; then conn="└──"; else conn="├──"; fi
  # Special handling for vendor/node_modules
  if [[ "$name" == "vendor" || "$name" == "node_modules" ]]; then
    entry "$conn" "📁 $name"
    # Nested listing
    if [[ "${STRUCTURE_MODE}" == "deep" ]]; then
      # determine nested prefix depending on lastness of this dir
      if [[ $index -eq $total ]]; then nested_prefix="$(cont_prefix 1)"; else nested_prefix="$(cont_prefix 0)"; fi
      mapfile -t SUBS < <(find "${PROJECT_PATH}/${name}" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | LC_ALL=C sort)
      subcount=${#SUBS[@]}
      if [[ $subcount -gt 0 ]]; then
        subi=0
        for sub in "${SUBS[@]}"; do
          subi=$((subi+1))
          if [[ $subi -eq $subcount ]]; then subconn="└──"; else subconn="├──"; fi
          line "${nested_prefix}${subconn} 📁 $sub"
        done
      fi
    else
      # flat: show ellipsis only
      if [[ $index -eq $total ]]; then nested_prefix="$(cont_prefix 1)"; else nested_prefix="$(cont_prefix 0)"; fi
      line "${nested_prefix}└── ..."
    fi
  else
    entry "$conn" "📁 $name"
  fi
done

# Print files
for name in "${FILES[@]}"; do
  index=$((index+1))
  if [[ $index -eq $total ]]; then conn="└──"; else conn="├──"; fi
  entry "$conn" "$name"
done

close_fence
line ""

# --- .env section ---
line "## 🔍 Ausgewählte .env-Einträge"
line ""
open_fence
# Keep original order; show common keys if present
# (APP_* and DB_* subset; do not fail if missing)
sed -n -e '/^APP_/p' -e '/^DB_/p' "${PROJECT_PATH}/.env" >> "${SCAN_FILE}" || true
close_fence
line ""

# --- Versions ---
line "## 🧩 Laufzeit-Versionen"
line ""
open_fence
if command -v php >/dev/null 2>&1; then php -v | head -n 1 >> "${SCAN_FILE}"; else line "(php nicht gefunden)"; fi
if [[ -x "${PROJECT_PATH}/artisan" ]] && command -v php >/dev/null 2>&1; then php artisan --version >> "${SCAN_FILE}" 2>/dev/null || true; fi
if command -v node >/dev/null 2>&1; then node -v >> "${SCAN_FILE}"; else line "(node nicht gefunden)"; fi
if command -v npm  >/dev/null 2>&1; then npm -v  >> "${SCAN_FILE}"; else line "(npm nicht gefunden)"; fi
close_fence
line ""

# --- Composer ---
line "## 🧱 Composer-Abhängigkeiten"
line ""
line "### require"
open_fence
if [[ -f "${PROJECT_PATH}/composer.json" ]] && command -v jq >/dev/null 2>&1; then
  jq '.require // {}' "${PROJECT_PATH}/composer.json" >> "${SCAN_FILE}" || line "{}"
else
  line "{}"
fi
close_fence
line ""
line "### scripts"
open_fence
if [[ -f "${PROJECT_PATH}/composer.json" ]] && command -v jq >/dev/null 2>&1; then
  jq '.scripts // {}' "${PROJECT_PATH}/composer.json" >> "${SCAN_FILE}" || line "{}"
else
  line "{}"
fi
close_fence
line ""

# --- NPM ---
line "## 📦 NPM-Abhängigkeiten"
line ""
open_fence
if [[ -f "${PROJECT_PATH}/package.json" ]] && command -v jq >/dev/null 2>&1; then
  jq '.dependencies // {}' "${PROJECT_PATH}/package.json" >> "${SCAN_FILE}" || line "{}"
else
  line "{}"
fi
close_fence
line ""

# --- Vite ---
line "## ⚙️ Vite-Konfiguration"
line ""
open_fence
if [[ -f "${PROJECT_PATH}/vite.config.js" ]]; then
  head -n 40 "${PROJECT_PATH}/vite.config.js" >> "${SCAN_FILE}" || true
else
  line "(vite.config.js fehlt)"
fi
close_fence
line ""

# --- Weitere Configs (root) ---
line "## 📄 Weitere Konfigurationsdateien"
line ""
open_fence
find "${PROJECT_PATH}" -maxdepth 1 -type f   \( -name '*.config.js' -o -name '*.neon' -o -name '*.yaml' -o -name '*.yml' -o -name '*.toml' -o -name '*.ini' \)   -printf '%f\n' 2>/dev/null | LC_ALL=C sort >> "${SCAN_FILE}" || true
close_fence
line ""

# --- housekeeping: keep only last 5 reports for each type ---
cleanup_keep_last() {
  local pattern="$1"
  local keep="${2:-5}"
  # use ls -t, ignore errors if no files match
  mapfile -t files < <(ls -1t $pattern 2>/dev/null || true)
  local count="${#files[@]}"
  if [[ $count -gt $keep ]]; then
    local to_remove=("${files[@]:$keep}")
    # shellcheck disable=SC2086
    rm -f -- ${to_remove[@]} 2>/dev/null || true
  fi
}

cleanup_keep_last "${SCAN_DIR}/project_scan_[0-9]*.md" 5
cleanup_keep_last "${SCAN_DIR}/project_scan_deep_[0-9]*.md" 5

# success: no stdout
exit 0
