#!/usr/bin/env bash
# log_render_html.sh — rendert LOG-YYYYMMDD.md zu HTML (Projekt & ~/bin) mit CSS-Autopolicy
# Version: v0.6.6  # fixes: no hang, no pandoc deprec. warn, force --from=gfm, tmp .md, robust log_core usage

# ---- Shell safety ------------------------------------------------------------
if [ -z "${BASH_VERSION-}" ]; then exec bash "$0" "$@"; fi
set -Euo pipefail
IFS=$'\n\t'

SCRIPT_NAME="log_render_html.sh"
SCRIPT_VERSION="0.6.6"
ORIG_ARGS=("$@")
ORIG_CWD="$(pwd)"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"

# Wichtig für log_core.part (einige Versionen lesen diese ENV-Variablen)
export SCRIPT_NAME SCRIPT_VERSION
export VERSION="${SCRIPT_VERSION}"
export SCRIPT="${SCRIPT_NAME}"

# ---- Defaults / Autopolicy ---------------------------------------------------
DEBUG="OFF"
DATE_STR="$(date +%Y-%m-%d)"

DO_ALL=1          # Projekt + ~/bin
ONE_ROOT=""       # wenn gesetzt, genau dieser Root

AUTO_STRIP_MD_STYLE=1        # <style>…</style> im Markdown entfernen
AUTO_STRIP_TABLE_WIDTHS=1    # style="width:%" in <table>/<col> entfernen
REMOVE_COLGROUP=1            # <colgroup>…</colgroup> entfernen
WRAP_TABLES=1                # jede <table> in <div class="overflowx">…</div> packen
AUTO_NO_HIGHLIGHT=1          # Pandoc Syntax-Highlight abschalten

CSS_MODE="auto"              # auto | inline | link | none
NO_DEFAULT_CSS="auto"        # auto | 1 | 0

# ---- Options cell (non-break hyphen) -----------------------------------------
nbhy_all(){ printf '%s' "${1//-/$'\u2011'}"; }
render_opt_cell_html_multiline(){ local out=() t i n
  for t in "$@"; do out+=( "<span style=\"white-space:nowrap\"><code>$(nbhy_all "$t")</code></span>" ); done
  n=${#out[@]}; if ((n==0)); then printf '%s' "keine"; else for ((i=0;i<n;i++)); do printf '%s' "${out[i]}"; (( i<n-1 )) && printf '<br />'; done; fi
}
LC_OPT_CELL="keine"; LC_OPT_CELL_IS_HTML=1
((${#ORIG_ARGS[@]})) && LC_OPT_CELL="$(render_opt_cell_html_multiline "${ORIG_ARGS[@]}")"
export LC_OPT_CELL LC_OPT_CELL_IS_HTML
set +u; LC_ORIG_ARGS=("${ORIG_ARGS[@]}"); set -u

# ---- Help --------------------------------------------------------------------
usage(){ cat <<USAGE
Usage:
  ${SCRIPT_NAME} [--all] [--root=PATH] [--date=YYYY-MM-DD]
                 [--css=auto|inline|link|none]
                 [--no-default-css|--with-default-css]
                 [--keep-table-widths] [--no-strip-md-style]
                 [--keep-colgroup] [--no-wrap-tables]
                 [--highlight|--no-highlight]
                 [--debug=OFF|ON|TRACE] [--version] [--help]

Defaults (AUTOPOLICY):
  - Eigene CSS vorhanden (.markdownpdf-*.css, .shell_script_styles.logs.css):
      * Nur diese CSS verwenden, inline einbetten (keine <link>-Tags)
      * Keine Pandoc-Default-CSS
  - Keine eigenen CSS: Pandoc-Default-CSS
  - Markdown <style> wird entfernt, Tabellenbreiten & <colgroup> entfernt
  - Tabellen werden in <div class="overflowx">…</div> gewrappt
  - Pandoc Syntax-Highlight ist aus
USAGE
}

# ---- Parse args --------------------------------------------------------------
while (($#)); do
  case "$1" in
    --all) DO_ALL=1; ONE_ROOT="";;
    --root=*) DO_ALL=0; ONE_ROOT="${1#*=}"; [[ "${ONE_ROOT:0:2}" == "~/" ]] && ONE_ROOT="${HOME}/${ONE_ROOT:2}";;
    --date=*) DATE_STR="${1#*=}";;
    --css=*) CSS_MODE="${1#*=}";;
    --no-default-css) NO_DEFAULT_CSS=1;;
    --with-default-css) NO_DEFAULT_CSS=0;;
    --keep-table-widths) AUTO_STRIP_TABLE_WIDTHS=0;;
    --no-strip-md-style) AUTO_STRIP_MD_STYLE=0;;
    --keep-colgroup) REMOVE_COLGROUP=0;;
    --no-wrap-tables) WRAP_TABLES=0;;
    --highlight) AUTO_NO_HIGHLIGHT=0;;
    --no-highlight) AUTO_NO_HIGHLIGHT=1;;
    --debug=*) DEBUG="${1#*=}"; DEBUG="${DEBUG^^}";;
    --help) usage; exit 0;;
    --version) echo "${SCRIPT_NAME} ${SCRIPT_VERSION}"; exit 0;;
    *) echo "Unknown arg: $1" >&2; usage; exit 64;;
  esac
  shift
done

# ---- Debug -------------------------------------------------------------------
DEBUG_DIR="${HOME}/bin/debug"; mkdir -p "${DEBUG_DIR}"
DBG_TXT="${DEBUG_DIR}/log_render_html.debug.log"; : > "${DBG_TXT}"
if [ "${DEBUG}" = "TRACE" ]; then
  exec 19>>"${DEBUG_DIR}/log_render_html.xtrace.log"
  export BASH_XTRACEFD=19
  export PS4='+ '"${SCRIPT_NAME}"':${LINENO}:${FUNCNAME[0]-main} '
  set -x
fi
dbg(){ [ "${DEBUG}" != "OFF" ] && printf '[%s] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >> "${DBG_TXT}"; }

cleanup(){ set +e; exec 19>&- 2>/dev/null; }
trap cleanup EXIT

# ---- Reqs --------------------------------------------------------------------
require(){ command -v "$1" >/dev/null 2>&1 || { echo "❌ missing: $1" >&2; exit 127; }; }
require pandoc

# ---- log_core optional -------------------------------------------------------
LC_OK=0; HAS_INIT=0; HAS_FINALIZE=0; HAS_FIND_PROJ=0; HAS_SET_OPT=0
CTX_NAMES=()
if [ -r "${HOME}/bin/parts/log_core.part" ]; then
  set +u; . "${HOME}/bin/parts/log_core.part"; set -u
  command -v lc_log_event_all     >/dev/null 2>&1 && LC_OK=1 || LC_OK=0
  command -v lc_init_ctx          >/dev/null 2>&1 && HAS_INIT=1  || true
  command -v lc_finalize          >/dev/null 2>&1 && HAS_FINALIZE=1 || true
  command -v lc_find_project_root >/dev/null 2>&1 && HAS_FIND_PROJ=1 || true
  command -v lc_set_opt_cell      >/dev/null 2>&1 && HAS_SET_OPT=1 || true
  if [ "$HAS_SET_OPT" -eq 1 ]; then lc_set_opt_cell "${LC_OPT_CELL}" "${LC_OPT_CELL_IS_HTML}"; fi
fi

# Robust: prüfen ob MD/JSON-Ziele gesetzt sind, bevor geloggt wird
lc_can_log(){
  [ "$LC_OK" -eq 1 ] || return 1
  local ok=0 c m j
  for c in "${CTX_NAMES[@]:-}"; do
    m="$(eval "printf %s \"\${${c}_MD_FILE-}\"")"
    j="$(eval "printf %s \"\${${c}_JSON_FILE-}\"")"
    if [ -n "$m" ] && [ -n "$j" ]; then ok=1; else ok=0; break; fi
  done
  return "$(( ok==1 ? 0 : 1 ))"
}
safe_log_all(){ # passt args 1:... durch an lc_log_event_all, nur wenn möglich
  if lc_can_log; then set +u; lc_log_event_all "$@"; set -u; fi
}
safe_finalize(){ if lc_can_log && [ "$HAS_FINALIZE" -eq 1 ]; then set +u; lc_finalize; set -u; fi; }

# ---- Datum/Dateinamen --------------------------------------------------------
if ! y="$(date -d "${DATE_STR}" +%Y 2>/dev/null)"; then y="$(date +%Y)"; fi
if ! md_day="$(date -d "${DATE_STR}" +%Y%m%d 2>/dev/null)"; then md_day="$(date +%Y%m%d)"; fi
md_name="LOG-${md_day}.md"
html_name="LOG-${md_day}.html"

# ---- Helpers -----------------------------------------------------------------
strip_md_style_file(){ # $1 in.md -> stdout
  awk 'BEGIN{skip=0} /<style>/ {skip=1; next} /<\/style>/ {skip=0; next} skip==0 {print}' "$1"
}
css_chain_list(){ # $1 = dest_dir ; stdout: jeweils ein Pfad pro Zeile
  local d="$1"
  find "$d" -maxdepth 1 -type f -name '.markdownpdf-*.css' -printf '%p\n' 2>/dev/null | sort
  if [ -f "${d}/.shell_script_styles.logs.css" ]; then echo "${d}/.shell_script_styles.logs.css"; fi
}
discover_project_root(){
  if [ "$HAS_FIND_PROJ" -eq 1 ]; then if pr="$(lc_find_project_root "$(pwd)")"; then printf '%s\n' "$pr"; return; fi; fi
  local d="$(pwd)"; while :; do [ -f "${d}/.env" ] && { printf '%s\n' "$d"; return; }
    [ "$d" = "/" ] && break; d="$(dirname -- "$d")"; done; printf '%s\n' "$(pwd)"
}
make_min_template(){ local t; t="$(mktemp)"; cat >"$t" <<'TPL'
$if(titleprefix)$
$endif$
<!DOCTYPE html>
<html lang="$lang$" xml:lang="$lang$" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<title>$pagetitle$</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
$for(css)$
<link rel="stylesheet" href="$css$" />
$endfor$
$for(header-includes)$
$header-includes$
$endfor$
</head>
<body>
$for(include-before)$
$include-before$
$endfor$
$body$
$for(include-after)$
$include-after$
$endfor$
</body>
</html>
TPL
  printf '%s\n' "$t"; }
postprocess_cleanup_html(){ # $1 in.html -> stdout
  awk -v rmcolgrp="${REMOVE_COLGROUP}" -v rmwidth="${AUTO_STRIP_TABLE_WIDTHS}" -v wraptbl="${WRAP_TABLES}" '
    function stripw(s){ if(rmwidth==1) gsub(/style="[^"]*width:[^"]*"/,"",s); return s }
    BEGIN{OFS=""; skip=0; in_table=0}
    {
      if (rmcolgrp==1) {
        if (skip==0 && $0 ~ /<colgroup[ >]/) { skip=1; next }
        if (skip==1) { if ($0 ~ /<\/colgroup>/) { skip=0; next } next }
      }
      line=$0
      if (line ~ /<table[ >]/) {
        line=stripw(line)
        if (wraptbl==1) { print "<div class=\"overflowx\">" }
        print line
        if (line ~ /<\/table>/) { if (wraptbl==1) print "</div>"; in_table=0 } else { in_table=1 }
        next
      }
      if (in_table==1) {
        if (line ~ /<col[ >]/ || line ~ /<table[ >]/) { line=stripw(line) }
        print line
        if (line ~ /<\/table>/) { if (wraptbl==1) print "</div>"; in_table=0 }
        next
      }
      if (line ~ /<col[ >]/ || line ~ /<table[ >]/) { line=stripw(line) }
      print line
    }
  ' "$1"
}
mk_log_dirs_for_root(){ local root="$1" y2; y2="$(date -d "${DATE_STR}" +%Y 2>/dev/null || date +%Y)"
  mkdir -p -- "${root}/.wiki/logs/${y2}" "${root}/.wiki/logs/json/${y2}"; }
build_css_log_msg(){ # $1 mode label; uses CSS_FILES[]
  local mode="$1" i=1
  local n="${#CSS_FILES[@]}"; if ((n==0)); then printf 'CSS: Pandoc-Default'; return; fi
  local first=1 f base
  for f in "${CSS_FILES[@]}"; do base="$(basename -- "$f")"
    if ((first)); then printf 'CSS:&nbsp;%d&nbsp;(%s)&nbsp;`%s`' "$i" "$mode" "$base"; first=0
    else printf '<br />CSS:&nbsp;%d&nbsp;(%s)&nbsp;`%s`' "$i" "$mode" "$base"; fi
    ((i++))
  done
}

# ---- BEGIN-Log ---------------------------------------------------------------
log_begin_event(){
  local debug_tag=""; [ "${DEBUG}" = "TRACE" ] && debug_tag=",trace" || { [ "${DEBUG}" = "ON" ] && debug_tag=",debug" || true; }
  local tags="render,html,begin${debug_tag}"
  local policy="auto" cssm="${CSS_MODE}" defcss="${NO_DEFAULT_CSS}"
  local opts="policy=${policy}; css=${cssm}; default-css=${defcss}; strip-md-style=${AUTO_STRIP_MD_STYLE}; strip-table-widths=${AUTO_STRIP_TABLE_WIDTHS}; remove-colgroup=${REMOVE_COLGROUP}; wrap-tables=${WRAP_TABLES}; no-highlight=${AUTO_NO_HIGHLIGHT}"
  safe_log_all INFO "render" "start" "plan" "✅" 0 0 "Date: \`${DATE_STR}\`" "${tags}" "${opts}"
}

# ---- Render-Pipeline ---------------------------------------------------------
render_one_root(){ # $1 root
  local root="$1"
  local log_dir="${root}/.wiki/logs/${y}"
  local css_dir="${root}/.wiki/logs"
  local md="${log_dir}/${md_name}"
  local out="${log_dir}/${html_name}"

  if [ ! -f "$md" ]; then echo "⚠️  missing Markdown: ${md}"; return 0; fi

  # Quelle (ggf. <style> strippen) → temp .md (mit Endung, damit Pandoc nicht rät)
  local src_md="$md" tmp_src=""
  if [ "$AUTO_STRIP_MD_STYLE" -eq 1 ]; then
    tmp_src="$(mktemp).md"
    strip_md_style_file "$md" > "$tmp_src" || true
    src_md="$tmp_src"
  fi

  # CSS-Chain aus @dest
  mapfile -t CSS_FILES < <(css_chain_list "$css_dir" || true)
  local have_css=0; (( ${#CSS_FILES[@]} > 0 )) && have_css=1

  # Modus bestimmen
  local use_inline=0 use_link=0 use_default_css=0 mode_label=""
  case "$CSS_MODE" in
    inline) use_inline=1; mode_label="inline";;
    link)   use_link=1;  mode_label="link";;
    none)   use_inline=0; use_link=0; mode_label="";;
    auto)   if [ "$have_css" -eq 1 ]; then use_inline=1; mode_label="inline"; else use_inline=0; use_link=0; mode_label=""; fi ;;
    *) echo "❌ invalid --css mode: $CSS_MODE" >&2; exit 64;;
  esac
  if [ "$NO_DEFAULT_CSS" = "auto" ]; then
    [ "$have_css" -eq 1 ] && use_default_css=0 || use_default_css=1
  else
    if [ "${NO_DEFAULT_CSS}" -eq 1 ]; then use_default_css=0; else use_default_css=1; fi
  fi

  # Pandoc-Args (keine Deprecation: --embed-resources statt --self-contained)
  local PANDOC_ARGS=( --standalone --from=gfm --to=html5 --metadata "title=Logs ${md_day}" )
  [ "$AUTO_NO_HIGHLIGHT" -eq 1 ] && PANDOC_ARGS+=( --no-highlight )
  local tmpl=""
  if [ "$use_default_css" -eq 0 ]; then
    tmpl="$(make_min_template)"
    PANDOC_ARGS+=( --template "$tmpl" )
  fi
  if [ "$use_inline" -eq 1 ]; then
    PANDOC_ARGS+=( --embed-resources )
  fi

  local CSS_ARGS=()
  if [ "$have_css" -eq 1 ] && { [ "$use_inline" -eq 1 ] || [ "$use_link" -eq 1 ]; }; then
    local f; for f in "${CSS_FILES[@]}"; do CSS_ARGS+=( -c "$f" ); done
  fi

  # Render → Postprocess
  local tmp_html; tmp_html="$(mktemp)"
  if pandoc "${PANDOC_ARGS[@]}" "${CSS_ARGS[@]}" -o "$tmp_html" "$src_md"; then
    postprocess_cleanup_html "$tmp_html" > "$out"
    rm -f "$tmp_html" "${tmp_src:-}" "${tmpl:-}"
    echo "✅  HTML gerendert: \`$out\`"
    if (( ${#CSS_FILES[@]} > 0 )); then
      local css_msg; css_msg="$(build_css_log_msg "${mode_label}")"
      safe_log_all INFO "render" "html" "\`${md_name}\`" "✅" 0 0 "Root: \`$root\`" "render,html,pandoc" "${css_msg}"
    else
      safe_log_all INFO "render" "html" "\`${md_name}\`" "✅" 0 0 "Root: \`$root\`" "render,html,pandoc" "CSS: Pandoc-Default"
    fi
  else
    echo "❌  pandoc failed for \`$md\`" >&2
    safe_log_all ERROR "render" "html" "\`${md_name}\`" "❌" 0 1 "Root: \`$root\`" "render,html,pandoc" "pandoc failed"
    rm -f "$tmp_html" "${tmp_src:-}" "${tmpl:-}"
    return 1
  fi
}

# ---- Main --------------------------------------------------------------------
main(){
  # Roots
  local roots=() project_root
  project_root="$(discover_project_root)"
  if [ "$DO_ALL" -eq 1 ]; then roots=( "$project_root" "${HOME}/bin" )
  else
    [ -n "$ONE_ROOT" ] || { echo "❌ --root=PATH required when --all not set" >&2; exit 64; }
    roots=( "$ONE_ROOT" )
  fi

  # Log-Verzeichnisse
  mk_log_dirs_for_root "$project_root"
  mk_log_dirs_for_root "${HOME}/bin"

  # log_core-Kontexte
  if [ "$LC_OK" -eq 1 ] && [ "$HAS_INIT" -eq 1 ]; then
    set +u
    lc_init_ctx "BIN"     "${HOME}/bin"         "${RUN_ID}" "${SCRIPT_NAME}" "${SCRIPT_VERSION}" "${ORIG_CWD}" "render-html"
    CTX_NAMES+=("BIN")
    lc_init_ctx "PRIMARY" "${project_root}"     "${RUN_ID}" "${SCRIPT_NAME}" "${SCRIPT_VERSION}" "${ORIG_CWD}" "render-html"
    CTX_NAMES=("PRIMARY" "${CTX_NAMES[@]}")
    [ "$HAS_SET_OPT" -eq 1 ] && lc_set_opt_cell "${LC_OPT_CELL}" "${LC_OPT_CELL_IS_HTML}" || true
    set -u
  fi

  # BEGIN-Event
  log_begin_event

  # Render (dedupe)
  local rc=0 r; declare -A seen=()
  for r in "${roots[@]}"; do
    [ -z "$r" ] && continue
    r="$(cd "$r" 2>/dev/null && pwd || echo "$r")"
    [ -n "${seen[$r]-}" ] && continue
    seen["$r"]=1
    render_one_root "$r" || rc=1
  done

  safe_finalize
  exit "$rc"
}

main "$@"
