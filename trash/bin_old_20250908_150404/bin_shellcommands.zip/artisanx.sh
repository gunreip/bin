#!/usr/bin/env bash
# artisanx.sh — smarter php artisan Wrapper (nur aus Projekt-Root!)
# Version: 0.3.2
# Changelog:
# - 0.3.2: STRICT ROOT — nur aus <project>-Root; keine Root-Autosuche mehr
# - 0.3.1: console Datei als MD (artisanx_console_<ts>.md)
# - 0.3.0: list default; capture + preview
# - 0.2.0: Default REAL RUN; --dry-run; env-Fix
set -o pipefail

VERSION="0.3.2"
SCRIPT_NAME="artisanx"

usage(){ cat <<'EOF'
artisanx — Wrapper für php artisan (NUR im Projekt-Root ausführen)
Usage:
  artisanx [--dry-run] [--format md|txt|json] [--out <file>]
           [--color auto|always|never] [--memory <VAL>] [--debug]
           [--capture-lines <N>]
           [--version] -- <artisan args...>
EOF
}

DRY_RUN=0; FORMAT="md"; OUTFILE=""; COLOR_MODE="auto"; DEBUG=0; PHP_MEMORY="${ARTISANX_MEMORY:-1G}"; CAPTURE_LINES=120
setup_colors(){ local use=0; case "$COLOR_MODE" in always)use=1;;never)use=0;;auto) [[ -t 1 ]]&&use=1||use=0;; esac
  if [[ $use -eq 1 ]]; then BOLD=$'\e[1m'; DIM=$'\e[2m'; RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; BLUE=$'\e[34m'; RESET=$'\e[0m'
  else BOLD=""; DIM=""; RED=""; GREEN=""; YELLOW=""; BLUE=""; RESET=""; fi; }
dbg(){ [[ $DEBUG -eq 1 ]] && printf "%s[DBG]%s %s\n" "$DIM" "$RESET" "$*" >&2; }
while [[ $# -gt 0 ]]; do case "$1" in
  --dry-run) DRY_RUN=1 ;; --format) FORMAT="${2:-md}"; shift ;;
  --out) OUTFILE="${2:-}"; shift ;; --color) COLOR_MODE="${2:-auto}"; shift ;;
  --memory) PHP_MEMORY="${2:-1G}"; shift ;; --debug) DEBUG=1 ;;
  --capture-lines) CAPTURE_LINES="${2:-120}"; shift ;;
  --version) echo "$VERSION"; exit 0 ;; -h|--help) usage; exit 0 ;;
  --) shift; ARGS+=("$@"); break ;; *) ARGS+=("$1") ;; esac; shift; done
setup_colors

# STRICT ROOT
PROJECT_ROOT="$PWD"
[[ -f "$PROJECT_ROOT/artisan" ]] || { echo "${RED}[ERROR]${RESET} 'artisan' fehlt im aktuellen Ordner." >&2; exit 2; }
[[ -f "$PROJECT_ROOT/.env" ]] || { echo "${RED}[ERROR]${RESET} .env fehlt im aktuellen Ordner." >&2; exit 2; }
cd "$PROJECT_ROOT"

# ENV (nur nötige Keys)
# shellcheck disable=SC2046
export $(grep -E '^(APP_ENV|APP_URL|DB_HOST|DB_DATABASE|DB_USERNAME|DB_PASSWORD)$' .env | xargs) || true
mask(){ sed -E 's/([A-Za-z0-9]{2})([A-Za-z0-9]+)([A-Za-z0-9]{2})/\1******\3/g'; }
ts(){ date +"%Y-%m-%d %H:%M:%S%z"; }

# .wiki Pfade
WIKI_DIR="$PROJECT_ROOT/.wiki/dev/cli"; mkdir -p "$WIKI_DIR"; find "$WIKI_DIR" -type f -mtime +30 -delete 2>/dev/null || true
TS_FILE="$(date +%F_%H%M%S)"

# Args default
[[ ${#ARGS[@]:-0} -eq 0 ]] && ARGS=( list )

# Command & run
CMD=( php -d "memory_limit=${PHP_MEMORY}" -d "zend.exception_ignore_args=0" artisan "${ARGS[@]}" )
ARTISAN_STR="$(printf "%q " "${CMD[@]}")"
EXIT=0; START_EPOCH=$(date +%s); PREVIEW=""; CONSOLE_MD="$WIKI_DIR/artisanx_console_${TS_FILE}.md"

if [[ $DRY_RUN -eq 1 ]]; then
  PREVIEW="$(php artisan -V 2>/dev/null | head -n1 || true)"
  {
    echo "# artisanx console (dry-run) — v${VERSION}"
    echo "Zeit: $(ts)"; echo; echo "Command:"; echo '```bash'; echo "${ARTISAN_STR} --no-interaction"; echo '```'; echo
    echo "Output (nur Info-Zeile, da --dry-run):"; echo '```'; [[ -n "$PREVIEW" ]] && echo "$PREVIEW"; echo '```'
  } > "$CONSOLE_MD"
  RUNTIME_SEC=0
else
  TMP_RAW="$(mktemp)"; set +e
  env XDEBUG_MODE=off COMPOSER_DISABLE_XDEBUG_WARN=1 "${CMD[@]}" --no-interaction 2>&1 | tee "$TMP_RAW"
  EXIT=${PIPESTATUS[0]}; set -e
  PREVIEW="$(head -n "$CAPTURE_LINES" "$TMP_RAW" 2>/dev/null || true)"
  {
    echo "# artisanx console — v${VERSION}"
    echo "Zeit: $(ts)"; echo; echo "Command:"; echo '```bash'; echo "${ARTISAN_STR} --no-interaction"; echo '```'; echo
    echo "Output:"; echo '```'; cat "$TMP_RAW"; echo '```'
  } > "$CONSOLE_MD"; rm -f "$TMP_RAW"; RUNTIME_SEC=$(( $(date +%s) - START_EPOCH ))
fi

APP_URL_SAFE="$(printf "%s" "${APP_URL:-}" | mask)"; DB_USER_SAFE="$(printf "%s" "${DB_USERNAME:-}" | mask)"

# Formatter
to_md(){ cat <<EOF
# artisanx Report (v${VERSION})
Zeit: $(ts)
Projekt: $PROJECT_ROOT
APP_ENV: ${APP_ENV:-}
APP_URL: ${APP_URL_SAFE:-}
DB_USER: ${DB_USER_SAFE:-}
Dry-Run: $([[ $DRY_RUN -eq 1 ]] && echo YES || echo NO)
Memory: ${PHP_MEMORY}
Xdebug: off

## Command
\`\`\`bash
${ARTISAN_STR}
\`\`\`

## Ergebnis
Exit-Code: ${EXIT}
Runtime: ${RUNTIME_SEC}s
Konsole (erste ${CAPTURE_LINES} Zeilen):
\`\`\`
${PREVIEW}
\`\`\`

Vollständige Konsole: \`$(basename "$CONSOLE_MD")\`
EOF
}
to_txt(){ echo "script=$SCRIPT_NAME version=$VERSION time=$(ts) project=$PROJECT_ROOT dry_run=$DRY_RUN exit=$EXIT runtime=${RUNTIME_SEC}s memory=$PHP_MEMORY"
  echo "cmd=${ARTISAN_STR}"; echo "console_file=$(basename "$CONSOLE_MD")"; echo "preview_start"; printf "%s\n" "$PREVIEW"; echo "preview_end"; }
to_json(){ if command -v jq >/dev/null; then
  jq -n --arg script "$SCRIPT_NAME" --arg version "$VERSION" --arg time "$(ts)" --arg project "$PROJECT_ROOT" \
    --arg cmd "$ARTISAN_STR" --arg mem "$PHP_MEMORY" --arg console_file "$(basename "$CONSOLE_MD")" \
    --arg preview "$PREVIEW" --argjson preview_lines "$CAPTURE_LINES" \
    --argjson dry $([[ $DRY_RUN -eq 1 ]]&&echo true||echo false) --argjson exit "$EXIT" --argjson runtime "$RUNTIME_SEC" \
    '{script:$script,version:$version,time:$time,project:$project,dry_run:$dry,php_memory:$mem,cmd:$cmd,exit:$exit,runtime_sec:$runtime,console:{file:$console_file,preview_lines:$preview_lines,preview:$preview}}'
  else to_txt; fi; }

CONTENT=""; case "$FORMAT" in md) CONTENT="$(to_md)";; txt) CONTENT="$(to_txt)";; json) CONTENT="$(to_json)";; *) echo "${RED}bad --format${RESET}" >&2; exit 2;; esac
F="$WIKI_DIR/${TS_FILE}_artisanx.${FORMAT}"; [[ $DRY_RUN -eq 1 ]] && echo "[DRY-RUN] würde schreiben: $F" || printf "%s\n" "$CONTENT" > "$F"
printf "%s\n" "$CONTENT" > "$WIKI_DIR/last.${FORMAT}"
exit $EXIT
