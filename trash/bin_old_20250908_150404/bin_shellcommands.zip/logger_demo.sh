#!/usr/bin/env bash
# logger_demo.sh — Demonstration für proj_logger (Markdown-Tabellen, Sections)
# Version: v1.1.0
set -euo pipefail

usage() {
  cat <<'HLP'
logger_demo — schreibt Beispiel-Logs ins Projekt (.wiki/logs/YYYY-MM-DD.{md|log})

USAGE
  logger_demo [--project <path>] [--dry-run] [--format md|txt] [--help] [--version]

OPTIONEN
  --project <path>   Projektverzeichnis (Default: aktuelles Verzeichnis)
  --dry-run          Nur „würde tun“-Einträge (keine riskanten Kommandos)
  --format md|txt    Logformat überschreiben (Default: md)
  -h, --help         Hilfe
  --version          Version

Voraussetzung: ~/bin/proj_logger.sh (wird via 'source' geladen).
HLP
}

VERSION="v1.1.0"
PROJECT_DIR="$PWD"
DRY=0
FORMAT="md"   # Default: Markdown-Tabellen

# Args
while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) PROJECT_DIR="$2"; shift 2;;
    --dry-run) DRY=1; shift;;
    --format)  FORMAT="$2"; shift 2;;
    --version) echo "$VERSION"; exit 0;;
    -h|--help) usage; exit 0;;
    *) echo "Unbekannter Parameter: $1" >&2; usage; exit 1;;
  esac
done

# Logger-Library laden
if [[ ! -f "$HOME/bin/proj_logger.sh" ]]; then
  echo "Fehler: ~/bin/proj_logger.sh nicht gefunden. Bitte zuerst proj_logger installieren." >&2
  exit 2
fi
# shellcheck disable=SC1091
source "$HOME/bin/proj_logger.sh"

# Projekt prüfen & wechseln
if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Fehler: Projektpfad existiert nicht: $PROJECT_DIR" >&2
  exit 3
fi
cd "$PROJECT_DIR"

# Format setzen (md/txt) und Prefix definieren
case "$FORMAT" in
  md|txt) export PROJ_LOG_FORMAT="$FORMAT" ;;
  *) echo "Warnung: ungültiges --format '$FORMAT' -> benutze md"; export PROJ_LOG_FORMAT="md" ;;
esac
export PROJ_LOG_PREFIX="$(basename "$PROJECT_DIR")|logger_demo"

# Init (legt <project>/.wiki/logs/YYYY-MM-DD.{md|log} an + Retention)
log_init

# SECTION: Meta
log_section "Meta"
log_info  "Demo gestartet (v${VERSION}) — dry-run=${DRY} • user=${USER:-unknown} • host=$(hostname -s 2>/dev/null || echo '?')"

# SECTION: .env (ohne Secrets)
log_section ".env"
if [[ -f .env ]]; then
  APP_ENV="$(grep -E '^APP_ENV=' .env 2>/dev/null | cut -d= -f2- || echo '-')"
  APP_URL="$(grep -E '^APP_URL=' .env 2>/dev/null | cut -d= -f2- || echo '-')"
  log_info "APP_ENV=${APP_ENV:-'-'} | APP_URL=${APP_URL:-'-'}"
else
  log_warn ".env fehlt – Logging läuft trotzdem (Best-Effort)."
fi

# SECTION: Git
log_section "Git"
branch="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo '-')"
commit="$(git rev-parse --short HEAD 2>/dev/null || echo '-')"
log_info "branch=${branch} | commit=${commit}"
log_cmd  "Zähle ungetrackte Dateien" bash -c "git ls-files --others --exclude-standard | wc -l"

# SECTION: Files
log_section "Files"
log_cmd "Zeige Top-Level-Dateien" ls -la

# SECTION: Dry-Run / Actions
log_section "Actions"
if (( DRY )); then
  log_dry "würde: sudo nginx -t"
  log_dry "würde: systemctl reload nginx"
else
  log_cmd "Zeige Datum" date
fi

# Abschluss
lf="$(log_file)"
log_info "Demo fertig. Logfile: ${lf:-<unbekannt>}"
printf "Logfile: %s\n" "${lf:-<unbekannt>}"
exit 0
