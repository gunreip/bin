#!/usr/bin/env bash
SCRIPT_VERSION="v0.2.0"
set -euo pipefail

REMOTE="origin"; BRANCH=""; DRY=0; STASH=0

print_help(){ cat <<'HLP'
git_sync_rebase.sh — holt Änderungen und rebased lokalen Branch auf Remote (nur im Projekt-WD)

USAGE
  git_sync_rebase.sh [OPTS]

OPTIONEN
  --remote <name>  Remote-Name (Default: origin)
  --branch <name>  Branch (Default: aktueller Branch)
  --stash          Unsaubere Arbeitsbäume vor Rebase automatisch stashen & danach poppen
  --dry-run        Nur anzeigen, was ausgeführt würde
  --version        Skriptversion
  -h, --help       Hilfe

HINWEIS
  • Gatekeeper: Skript muss im Projekt-WD mit .env laufen.
HLP
}

usage(){ print_help; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --remote) REMOTE="$2"; shift 2;;
    --branch) BRANCH="$2"; shift 2;;
    --stash) STASH=1; shift;;
    --dry-run) DRY=1; shift;;
    --version) printf '%s\n' "$SCRIPT_VERSION"; exit 0;;
    -h|--help) print_help; exit 0;;
    *) printf 'Unbekannter Parameter: %s\n' "$1" >&2; usage;;
  esac
done

[[ -f .env ]] || { echo 'Fehler: .env fehlt. Skript nur im Projektordner ausführen.' >&2; exit 2; }
command -v git >/dev/null || { echo 'Fehler: git nicht gefunden.' >&2; exit 3; }

run(){ if [[ "$DRY" -eq 1 ]]; then echo "[DRY] $*"; else eval "$@"; fi }
[[ -n "${BRANCH:-}" ]] || BRANCH="$(git rev-parse --abbrev-ref HEAD)"

dirty=0; git diff --quiet || dirty=1; git diff --quiet --cached || dirty=1
if [[ "$dirty" -eq 1 && "$STASH" -eq 0 ]]; then
  echo 'Fehler: Arbeitsbaum nicht sauber. Verwende --stash oder committe zuerst.' >&2; exit 4
fi
if [[ "$dirty" -eq 1 && "$STASH" -eq 1 ]]; then run "git stash push -u -m 'auto-stash before rebase $(date +%F_%T)'"; fi

run "git fetch \"$REMOTE\" --prune"
run "git rebase \"$REMOTE/$BRANCH\""

if [[ "$STASH" -eq 1 ]]; then
  if git stash list | grep -q 'auto-stash before rebase'; then run "git stash pop || true"; fi
fi

run "git log --oneline -n 5 --decorate --graph"
