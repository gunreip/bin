#!/usr/bin/env bash
# log_test.sh – Projekt-Logs in .wiki/logs/ (Markdown + JSONL)
# Version: 0.8.5
# Verhalten:
#   --version         -> zeigt Versionsnummer und beendet
#   --bump-patch      -> x.y.z -> x.y.(z+1), persistiert im Skript
#   --bump-minor      -> x.y.z -> x.(y+1).0, persistiert im Skript
#   --bump-major      -> x.y.z -> (x+1).0.0, persistiert im Skript
#   --no-wipe         -> heutige Logs NICHT löschen (Default: löschen/neu schreiben)
#   übrige Argumente  -> werden als "Optionen" geloggt (Spalte + JSON, ohne reines "--")

set -Eeuo pipefail
IFS=$'\n\t'

VERSION="0.8.5"

# ------------ Icons ------------
ok(){   printf "✅"; }
warn(){ printf "⚠️"; }
bad(){  printf "❌"; }

# ------------ Zeit/Helfer ------------
ts_utc(){ date -u +"%Y-%m-%dT%H:%M:%SZ"; }
ts_local(){ TZ="$TZ_RUN" date +"%H:%M:%S"; }
date_de(){ TZ="$TZ_RUN" date +"%d.%m.%Y"; }
date_compact(){ TZ="$TZ_RUN" date +"%Y%m%d"; }
year_y(){ TZ="$TZ_RUN" date +"%Y"; }

user_name(){ id -un; }
host_name(){ hostname; }
script_name="$(basename "$0")"
run_id="$(date -u +%Y%m%dT%H%M%SZ)-$$"
pid="$$"

# ------------ JSON/MD Helpers ------------
jesc(){ printf "%s" "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e ':a;N;$!ba;s/\n/\\n/g'; }
md_escape_pipes(){ sed -e 's/|/\\|/g'; }
ZWJ=$'\u200d'
md_hyphen_zwj(){ awk -v ZWJ="$ZWJ" '{gsub(/-/, ZWJ "-" ZWJ); print}'; }
md_code_cell(){ local s; s="$(cat)"; s="$(printf "%s" "$s" | md_hyphen_zwj | md_escape_pipes)"; [[ -z "$s" ]] && return 0; printf '`%s`' "$s"; }
md_text_cell(){ local s; s="$(cat)"; s="$(printf "%s" "$s" | md_hyphen_zwj | md_escape_pipes)"; printf "%s" "$s"; }
redact(){ sed -E 's/(PASSWORD|SECRET|TOKEN|APP_KEY|PGPASSWORD)=([^[:space:]]+)/\1=********/gI'; }

trim_trailing_blanks(){ local f="$1" tmp; tmp="$(mktemp)"; awk '{a[NR]=$0} NF{last=NR} END{for(i=1;i<=last;i++) print a[i]}' "$f" > "$tmp" && mv "$tmp" "$f"; }

# ------------ .env lesen ------------
env_get(){ local key="$1" line val; line="$(grep -E "^[[:space:]]*${key}=" .env | tail -n1 | sed -E "s/^[[:space:]]*${key}=(.*)$/\1/" | tr -d '\r' || true)"; val="$line"
  [[ "$val" =~ ^\".*\"$ ]] && val="${val:1:-1}"; [[ "$val" =~ ^\'.*\'$ ]] && val="${val:1:-1}"; printf "%s" "$val"; }

# ------------ Version-Bumping ------------
bump(){ local kind="$1" M m p; IFS=. read -r M m p <<<"$VERSION"
  case "$kind" in patch) p=$((p+1));; minor) m=$((m+1)); p=0;; major) M=$((M+1)); m=0; p=0;; esac
  local new="${M}.${m}.${p}"
  sed -E -i "s/^(VERSION=\")([0-9]+\.[0-9]+\.[0-9]+)(\")/\1${new}\3/" "$0"
  sed -E -i "s/^(# Version:\s*)([0-9]+\.[0-9]+\.[0-9]+)/\1${new}/" "$0"
  VERSION="$new"; echo "$VERSION"; }

# ========== Argumente ==========
ORIG_ARGS=("$@"); WIPE=1
case "${1:-}" in
  --version) echo "$VERSION"; exit 0 ;;
  --bump-patch) bump patch; exit 0 ;;
  --bump-minor) bump minor; exit 0 ;;
  --bump-major) bump major; exit 0 ;;
  --no-wipe) WIPE=0; shift ;;
esac

opts_to_json(){ local arr=() a trimmed; for a in "${ORIG_ARGS[@]:-}"; do [[ "$a" == "--" ]] && continue; trimmed="${a//[[:space:]]/}"; [[ -z "$trimmed" ]] && continue; arr+=("$a"); done
  if ((${#arr[@]}==0)); then printf '[]'; else
    printf '%s\n' "${arr[@]}" | awk 'BEGIN{printf("[");f=1}{gsub(/\\/,"\\\\"); gsub(/"/,"\\\""); if(!f) printf(","); printf("\"%s\"",$0); f=0}END{printf("]")}'
  fi; }

opts_to_md_cell(){ local arr=() a trimmed; for a in "${ORIG_ARGS[@]:-}"; do [[ "$a" == "--" ]] && continue; trimmed="${a//[[:space:]]/}"; [[ -z "$trimmed" ]] && continue; arr+=("$a"); done
  if ((${#arr[@]}==0)); then printf "keine"; else local out="" line cell; for line in "${arr[@]}"; do cell="$(printf "%s" "$line" | md_code_cell)"; [[ -z "$cell" ]] && continue; [[ -z "$out" ]] && out="$cell" || out="${out}<br/>${cell}"; done; [[ -z "$out" ]] && printf "keine" || printf "%s" "$out"; fi; }

csv_to_json_array(){ awk -v s="$1" 'BEGIN{n=split(s,a,","); printf("["); c=0; for(i=1;i<=n;i++){gsub(/^[ \t]+|[ \t]+$/, "", a[i]); if(a[i]!=""){gsub(/\\/,"\\\\",a[i]); gsub(/"/,"\\\"",a[i]); if(c++) printf(","); printf("\"" a[i] "\"");}} printf("]") }'; }

die(){ printf "[ERROR] %s\n" "$*" >&2; exit 1; }

# ========== Gatekeeper ==========
[[ -f .env && -f artisan ]] || die "Kein Projektordner (.env + artisan fehlen)."
PROJ_NAME="$(env_get PROJ_NAME)"; [[ -n "$PROJ_NAME" ]] || PROJ_NAME="$(basename "$(pwd)")"
TZ_RUN="$(env_get PROJ_TIMEZONE)"; [[ -n "$TZ_RUN" ]] || TZ_RUN="Europe/Berlin"
GIT_REV="$(git rev-parse --short HEAD 2>/dev/null || true)"

# ========== Pfade ==========
Y="$(year_y)"; D_compact="$(date_compact)"; D_de="$(date_de)"
MD_DIR=".wiki/logs/${Y}"; JSON_DIR=".wiki/logs/json/${Y}"
MD_FILE="${MD_DIR}/LOG-${D_compact}.md"; JSON_FILE="${JSON_DIR}/LOG-${D_compact}.jsonl"
mkdir -p "$MD_DIR" "$JSON_DIR"
[[ $WIPE -eq 1 ]] && rm -f "$MD_FILE" "$JSON_FILE"

# ========== CSS NUR aus .wiki/logs/.shell_script_styles.css ==========
CSS_PATH=".wiki/logs/.shell_script_styles.css"
if [[ -f "$CSS_PATH" ]]; then
  MD_STYLE="$(printf "<style>\n%s\n</style>" "$(tr -d '\r' < "$CSS_PATH")")"
else
  MD_STYLE='`./.wiki/logs/.shell_script_styles.css` nicht gefunden!'
fi

# ========== Markdown: Style/Hinweis am Anfang ersetzen/setzen ==========
if [[ ! -f "$MD_FILE" ]]; then
  { printf "%s\n\n" "$MD_STYLE"; } > "$MD_FILE"
else
  tmp="$(mktemp)"
  # Entferne führenden <style>…</style>-Block ODER den „nicht gefunden!“-Hinweis (inkl. anschließender Leerzeilen)
  awk 'BEGIN{at_start=1; in_style=0; skipped_hint=0}
       {
         if (at_start) {
           if ($0 ~ /^<style>[[:space:]]*$/) { in_style=1; next }
           if (in_style) { if ($0 ~ /^<\/style>[[:space:]]*$/) { in_style=0; next } else next }
           if ($0 ~ /`\.\/\.wiki\/logs\/\.shell_script_styles\.css` nicht gefunden!/) { skipped_hint=1; next }
           if (skipped_hint && $0 ~ /^[[:space:]]*$/) { next }
           if ($0 ~ /^[[:space:]]*$/) { next }
           at_start=0
         }
         print
       }' "$MD_FILE" > "$tmp"
  { printf "%s\n\n" "$MD_STYLE"; cat "$tmp"; } > "$MD_FILE"
  rm -f "$tmp"
fi

# ========== Tageskopf (falls neu) ==========
if ! grep -q "^# Log - " "$MD_FILE"; then
  {
    echo "# Log - ${PROJ_NAME} -  ${D_de}"
    echo ""
    echo "- Pfad: \`$(pwd)\`"
    echo "- Host: \`$(host_name)\`"
    echo "- Zeitzone: \`${TZ_RUN}\`"
    [[ -n "$GIT_REV" ]] && echo "- Git: \`$GIT_REV\`"
    echo ""
  } >> "$MD_FILE"
fi

# ========== Start-Event JSON ==========
{
  printf '{'
  printf '"ts":"%s",'   "$(ts_utc)"
  printf '"tz":"%s",'   "$(jesc "$TZ_RUN")"
  printf '"lvl":"%s",'  "INFO"
  printf '"script":"%s",' "$(jesc "$script_name")"
  printf '"version":"%s",' "$(jesc "$VERSION")"
  printf '"project":"%s",' "$(jesc "$PROJ_NAME")"
  printf '"run_id":"%s",' "$(jesc "$run_id")"
  printf '"pid":%s,' "$pid"
  printf '"user":"%s",' "$(jesc "$(user_name)")"
  printf '"host":"%s",' "$(jesc "$(host_name)")"
  printf '"cwd":"%s",'  "$(jesc "$(pwd)")"
  printf '"git_rev":"%s",' "$(jesc "$GIT_REV")"
  printf '"section":"%s",' "start"
  printf '"action":"%s",'  "bootstrap"
  printf '"reason":"%s",'  "testsuite"
  printf '"tags":[],' 
  printf '"options":%s,' "$(opts_to_json)"
  printf '"result":{"status":"started"}'
  printf '}\n'
} >> "$JSON_FILE"

# ========== Markdown-Run-Header ==========
md_run_header(){
  echo ""                                # Leerzeile vor jedem Run-Block
  echo "## Run-ID: \`${run_id}\`"
  echo ""
  echo "| Zeit | Script | Version | Optionen | Sektion | Action | Grund | tags | Ergebnis | Dauer (ms) | Exit | User | Notiz | Skript-Meldungen |"
  echo "| --- | --- | ---: | --- | --- | --- | --- | --- | :---: | ---: | :---: | --- | --- | --- |"
}
md_run_header >> "$MD_FILE"

# ========== Logger ==========
log_event(){
  local lvl="$1" sec="$2" act="$3" why="$4" status="$5" dur="$6" ex="${7:-0}" note="$8" tags_csv="${9:-}" script_msg="${10:-}"
  local icon tags_md
  case "$status" in ok) icon="$(ok)";; warn) icon="$(warn)";; error) icon="$(bad)";; *) icon="$status";; esac
  tags_md="$(printf "%s" "$tags_csv" | sed 's/,/, /g')"

  { printf '{'; printf '"ts":"%s",' "$(ts_utc)"; printf '"tz":"%s",' "$(jesc "$TZ_RUN")"; printf '"lvl":"%s",' "$(jesc "$lvl")"
    printf '"script":"%s",' "$(jesc "$script_name")"; printf '"version":"%s",' "$(jesc "$VERSION")"; printf '"project":"%s",' "$(jesc "$PROJ_NAME")"
    printf '"run_id":"%s",' "$(jesc "$run_id")"; printf '"pid":%s,' "$pid"; printf '"user":"%s",' "$(jesc "$(user_name)")"; printf '"host":"%s",' "$(jesc "$(host_name)")"
    printf '"cwd":"%s",'  "$(jesc "$(pwd)")"; printf '"git_rev":"%s",' "$(jesc "$GIT_REV")"
    printf '"section":"%s",' "$(jesc "$sec")"; printf '"action":"%s",' "$(jesc "$act")"; printf '"reason":"%s",' "$(jesc "$why")"
    printf '"tags":%s,' "$(csv_to_json_array "$tags_csv")"; printf '"options":%s,' "$(opts_to_json)"
    printf '"notes":"%s",' "$(jesc "$note")"; printf '"script_message":"%s",' "$(jesc "$script_msg")"
    printf '"result":{"status":"%s","code":%s},' "$(jesc "$status")" "$ex"; printf '"duration_ms":%s' "${dur:-0}"; printf '}\n'; } >> "$JSON_FILE"

  printf "| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |\n" \
    "$(ts_local)" \
    "$(printf "%s" "$script_name" | md_code_cell)" \
    "$(printf "%s" "$VERSION" | md_escape_pipes)" \
    "$(opts_to_md_cell)" \
    "$(printf "%s" "$sec" | md_text_cell)" \
    "$(printf "%s" "$act" | md_text_cell)" \
    "$(printf "%s" "$why" | md_text_cell)" \
    "$(printf "%s" "$tags_md" | md_text_cell)" \
    "$(printf "%s" "$icon")" \
    "$(printf "%s" "${dur:-0}" | md_escape_pipes)" \
    "$(printf "%s" "$ex" | md_escape_pipes)" \
    "$(printf "%s" "$(user_name)" | md_escape_pipes)" \
    "$(printf "%s" "$note" | md_text_cell)" \
    "$(printf "%s" "$script_msg" | md_text_cell)" \
    | redact >> "$MD_FILE"
}

# ========== Demo-Einträge ==========
sleep 0.1; log_event INFO  "setup"  "env-check"  "safety"    "ok"    120 0  "Projekt erkannt (.env + artisan)" "setup,env" ""
sleep 0.1; log_event INFO  "scan"   "files-scan" "inventory" "ok"     85 0  "Erfasste Dateien: 134"            "scan,inventory" ""
sleep 0.1; log_event WARN  "build"  "lint"       "codebase"  "warn"  210 0  "Style-Warnungen"                   "build,lint" "Lint: 5 Warnungen (max-line-len, quotes)"
sleep 0.1; log_event ERROR "build"  "compile"    "test"      "error"  57 2  "Fehlerfall simuliert"              "build,compile" "gcc exit 2: missing header xyz.h"
sleep 0.1; log_event INFO  "finish" "summary"    "testsuite" "ok"     10 0  "Demo abgeschlossen"                 "summary" ""

trim_trailing_blanks "$MD_FILE"
echo "✅ Logs geschrieben:"
echo " - ${MD_FILE}"
echo " - ${JSON_FILE}"
