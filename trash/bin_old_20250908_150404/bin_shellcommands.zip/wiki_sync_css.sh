#!/usr/bin/env bash
# wiki_sync_css.sh — synchronisiert CSS aus ~/bin/css in die @dest-Ziele
# Version: 0.10.9
#
# - Liest @dest-Zeilen aus *.css im SRC_DIR (Default: ~/bin/css)
#   Unterstützte Formen:
#     @dest: <pfad>
#     /* @dest: <pfad> */
#     # @dest: <pfad>
# - Pfadauflösung:
#     "~/" → $HOME/…   |  "/" → absolut  |  sonst relativ zu <project-root> (Gatekeeper: .env erforderlich)
# - Policy: Standard **no-create** (nur aktualisieren). Mit --allow-create dürfen fehlende Ziele angelegt/kopiert werden.
# - Logging:
#     * log_core.part (falls vorhanden): vollständige Markdown/JSON-Zeilen
#     * „Optionen“: alle CLI-Args, non-break-hyphen, je Option eine Zeile
#     * Per-File-Notiz: aufgelöste Targets als
#         Target 1: `/abs/pfad`<br />Target 2: `/abs/pfad2` …
#     * Summary: „Skript-Meldungen“ ohne „Source=…“
# - Debug-Files (pro Run neu geschrieben):
#     ~/bin/debug/wiki_sync_css.debug.log
#     ~/bin/debug/wiki_sync_css.debug.jsonl
#     ~/bin/debug/wiki_sync_css.xtrace.log

if [ -z "${BASH_VERSION-}" ]; then exec bash "$0" "$@"; fi
set -Euo pipefail
IFS=$'\n\t'

SCRIPT_NAME="wiki_sync_css.sh"
SCRIPT_VERSION="0.10.9"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
ORIG_ARGS=("$@")
ORIG_CWD="$(pwd)"

# ---------------- Optionen/Defaults ----------------
DRY_RUN=0
DEBUG="OFF"        # OFF|ON|TRACE
SRC_DIR="${HOME}/bin/css"
ALLOW_CREATE=0
RENDER_HTML=0      # optionaler Convenience-Call (log_render_html.sh) nach erfolgreichem Sync

usage() {
  cat <<'USAGE'
Verwendung:
  wiki_sync_css.sh [--dry-run] [--debug=OFF|ON|TRACE] [--src-dir=PATH]
                   [--allow-create] [--render-html]
                   [--help] [--version]

Standardwerte:
  --dry-run            = aus (0)
  --debug              = OFF
  --src-dir            = ~/bin/css
  --allow-create       = aus (0)   # ohne diese Option werden fehlende Dateien NICHT erzeugt
  --render-html        = aus (0)   # bei Erfolg danach log_render_html.sh aufrufen

Beschreibung:
  Sucht CSS-Quellen im SRC_DIR (*.css), liest @dest-Zeilen und kopiert die
  Quelle an alle Ziele. "~/" wird zu $HOME expandiert; absolute Pfade bleiben
  unverändert; relative Pfade werden zum Projekt-Root (Gatekeeper: .env) aufgelöst.
USAGE
}

# ---------------- Parse Args ----------------
while (($#)); do
  case "$1" in
    --dry-run) DRY_RUN=1;;
    --debug=*) DEBUG="${1#*=}"; DEBUG="${DEBUG^^}";;
    --src-dir=*) SRC_DIR="${1#*=}"; [[ "${SRC_DIR:0:2}" == "~/" ]] && SRC_DIR="${HOME}/${SRC_DIR:2}";;
    --allow-create) ALLOW_CREATE=1;;
    --render-html) RENDER_HTML=1;;
    --help) usage; exit 0;;
    --version) echo "${SCRIPT_NAME} ${SCRIPT_VERSION}"; exit 0;;
    *) echo "Unbekannte Option: $1" >&2; usage; exit 64;;
  esac
  shift
done

# ---------------- Debug Setup ----------------
DEBUG_DIR="${HOME}/bin/debug"; mkdir -p "${DEBUG_DIR}"
DBG_TXT="${DEBUG_DIR}/wiki_sync_css.debug.log"
DBG_JSON="${DEBUG_DIR}/wiki_sync_css.debug.jsonl"
XTRACE="${DEBUG_DIR}/wiki_sync_css.xtrace.log"
: > "${DBG_TXT}"
: > "${DBG_JSON}"
if [ "${DEBUG}" = "TRACE" ]; then
  : > "${XTRACE}"
  exec 19>>"${XTRACE}"
  export BASH_XTRACEFD=19
  export PS4='+ wiki_sync_css.sh:${LINENO}:${FUNCNAME[0]-main} '
  set -x
fi
dbg_line(){ [ "${DEBUG}" != "OFF" ] && printf '[%s] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >> "${DBG_TXT}"; }
dbg_json(){ [ "${DEBUG}" != "OFF" ] && printf '{"ts":"%s","event":"%s"%s}\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "${2:+,$2}" >> "${DBG_JSON}"; }

dbg_line "START ${SCRIPT_NAME} v${SCRIPT_VERSION} run_id=${RUN_ID} dry_run=${DRY_RUN} debug=${DEBUG}"
dbg_json "start" "\"script\":\"${SCRIPT_NAME}\",\"version\":\"${SCRIPT_VERSION}\",\"run_id\":\"${RUN_ID}\",\"cwd\":\"${ORIG_CWD}\",\"dry_run\":\"${DRY_RUN}\",\"debug\":\"${DEBUG}\""

# ---------------- Non-breaking hyphen + Optionen-Zelle ----------------
nbhy_all(){ printf '%s' "${1//-/$'\u2011'}"; }
render_opt_cell_html_multiline(){
  local out=() t
  for t in "${ORIG_ARGS[@]}"; do
    out+=( "<span style=\"white-space:nowrap\"><code>$(nbhy_all "$t")</code></span>" )
  done
  if ((${#out[@]}==0)); then
    printf '%s' "keine"
  else
    local i n; n=${#out[@]}
    for ((i=0;i<n;i++)); do printf '%s' "${out[i]}"; ((i<n-1)) && printf '<br />'; done
  fi
}
LC_OPT_CELL="keine"; LC_OPT_CELL_IS_HTML=1
LC_OPT_CELL="$(render_opt_cell_html_multiline)"

# ---------------- log_core.part (optional) ----------------
LC_OK=0; LC_HAS_INIT=0; LC_HAS_FINALIZE=0; LC_HAS_SETOPT=0
if [ -r "${HOME}/bin/parts/log_core.part" ]; then
  # shellcheck disable=SC1090
  . "${HOME}/bin/parts/log_core.part" || true
  # Übergib Original-Args an das Modul (für JSON-Optionen etc.)
  set +u
  LC_ORIG_ARGS=("${ORIG_ARGS[@]}")
  set -u
  if command -v lc_log_event_all >/dev/null 2>&1; then LC_OK=1; fi
  command -v lc_init_ctx      >/dev/null 2>&1 && LC_HAS_INIT=1 || true
  command -v lc_finalize      >/dev/null 2>&1 && LC_HAS_FINALIZE=1 || true
  command -v lc_set_opt_cell  >/dev/null 2>&1 && LC_HAS_SETOPT=1 || true
else
  echo "⚠️ log_core.part nicht geladen → kein Markdown/JSON-Lauf-Log (nur Debugfiles)."
fi

# ---------------- Gatekeeper: Projekt-Root ----------------
find_project_root(){
  local d; d="$(pwd)"
  while :; do
    if [ -f "${d}/.env" ]; then printf '%s\n' "$d"; return 0; fi
    [ "$d" = "/" ] && break
    d="$(dirname -- "$d")"
  done
  return 1
}
PROJECT_ROOT=""
if ! PROJECT_ROOT="$(find_project_root)"; then
  echo "❌ Gatekeeper: .env nicht gefunden (im Projekt-Root starten)." >&2
  dbg_line "Gatekeeper failed: no .env"
  dbg_json "gatekeeper" "\"ok\":0"
  if [ "${LC_OK}" -eq 1 ]; then
    set +u; lc_log_event_all ERROR "gate" "project" "missing .env" "❌" 0 2 "Start in project root required" "wiki,sync,gatekeeper" "aborted"; set -u
  fi
  exit 2
fi
dbg_line "Project detected: ${PROJECT_ROOT}"
dbg_json "var" "\"name\":\"PROJECT_ROOT\",\"value\":\"${PROJECT_ROOT//\"/\\\"}\""

# ---------------- log_core-Kontext initialisieren & CTX_NAMES fixen ----------------
if [ "${LC_OK}" -eq 1 ] && [ "${LC_HAS_INIT}" -eq 1 ]; then
  set +u
  lc_init_ctx "BIN"     "${HOME}/bin"     "${RUN_ID}" "${SCRIPT_NAME}" "${SCRIPT_VERSION}" "${ORIG_CWD}" "wiki-sync"
  lc_init_ctx "PRIMARY" "${PROJECT_ROOT}" "${RUN_ID}" "${SCRIPT_NAME}" "${SCRIPT_VERSION}" "${ORIG_CWD}" "wiki-sync"
  # Optionenzelle für Markdown/HTML im Modul hinterlegen
  [ "${LC_HAS_SETOPT}" -eq 1 ] && lc_set_opt_cell "${LC_OPT_CELL}" "${LC_OPT_CELL_IS_HTML}"
  # **WICHTIG**: Sicherstellen, dass die Kontexte im Modul tatsächlich registriert sind.
  # Einige Umgebungen verlieren CTX_NAMES → dann landet lc_log_event_all mit leerem Prefix.
  if ! declare -p CTX_NAMES >/dev/null 2>&1; then CTX_NAMES=(); fi
  case " ${CTX_NAMES[*]-} " in *" BIN "*) :;;      *) CTX_NAMES+=("BIN");; esac
  case " ${CTX_NAMES[*]-} " in *" PRIMARY "*) :;;  *) CTX_NAMES+=("PRIMARY");; esac
  set -u
else
  [ "${LC_OK}" -eq 1 ] && echo "⚠️ log_core.part vorhanden, aber lc_init_ctx fehlt → strukturiertes Logging deaktiviert." >&2
  LC_OK=0
fi

# ---------------- Helfer ----------------
trim(){ awk '{$1=$1}1'; }   # trim whitespace
# extrahiert alle @dest: …-Ziele aus einer CSS-Datei (eine pro Zeile)
extract_dests(){
  # $1 = css file
  awk '
    BEGIN{IGNORECASE=0}
    /@dest:/ {
      line=$0
      sub(/^.*@dest:[[:space:]]*/,"",line)
      # cutoff am nächsten Kommentar/Trailing
      sub(/[[:space:]]*\/\*.*$/,"",line)
      sub(/[[:space:]]*#[^`].*$/,"",line)
      gsub(/[[:space:]]+$/,"",line)
      gsub(/^[[:space:]]+/,"",line)
      if (length(line)>0) print line
    }
  ' "$1"
}

# Pfad-Auflösung gemäß Regeln
resolve_path(){
  local p="$1"
  if [[ "$p" == ~/* ]]; then
    printf '%s\n' "${HOME}/${p#~/}"
  elif [[ "$p" = /* ]]; then
    printf '%s\n' "$p"
  else
    printf '%s\n' "${PROJECT_ROOT}/${p}"
  fi
}

# Dateien gleich?
same_file(){ cmp -s -- "$1" "$2"; }

# Log-Formatter
fmt_count(){ printf '%s=%s' "$1" "$2"; }
format_targets_for_notiz(){
  # Args: absolute target paths
  local i=1 t lines=()
  for t in "$@"; do
    lines+=( "Target&nbsp;${i}:&nbsp;\`$t\`" )
    ((i++))
  done
  local out="" first=1 s
  for s in "${lines[@]}"; do
    if (( first )); then out="$s"; first=0; else out="${out}<br />${s}"; fi
  done
  printf '%s' "$out"
}

# ---------------- Scan Quellen ----------------
if [ ! -d "${SRC_DIR}" ]; then
  echo "⚠️ Keine Quellen unter ${SRC_DIR} gefunden."
  dbg_json "no_srcdir" "\"SRC_DIR\":\"${SRC_DIR//\"/\\\"}\""
  exit 0
fi
dbg_json "var" "\"name\":\"SRC_DIR\",\"value\":\"${SRC_DIR//\"/\\\"}\""

mapfile -t SOURCES < <(find "${SRC_DIR}" -maxdepth 1 -type f -name '*.css' -printf '%f\n' | sort)
SRC_COUNT="${#SOURCES[@]}"
if (( SRC_COUNT == 0 )); then
  echo "⚠️ Keine Quellen unter ${SRC_DIR} (*.css) gefunden."
  dbg_json "scan_collect" "\"src_dir\":\"${SRC_DIR//\"/\\\"}\",\"total\":\"0\""
  exit 0
fi
dbg_json "scan_collect" "\"src_dir\":\"${SRC_DIR//\"/\\\"}\",\"total\":\"${SRC_COUNT}\""

# BEGIN-Eintrag
if [ "${LC_OK}" -eq 1 ]; then
  set +u
  lc_log_event_all INFO "scan" "collect" "source" "✅" 0 0 "Sources: ${SRC_COUNT}" \
    "wiki, sync, shell-script, begin$( [ "${DEBUG}" = "TRACE" ] && echo ", trace" )$( [ "${ALLOW_CREATE}" -eq 1 ] && echo ", allow-create" )" \
    "Source: \`${SRC_DIR}\`"
  set -u
fi

# ---------------- Sync pro Datei ----------------
total_created=0
total_updated=0
total_identical=0
total_nodest=0
total_errors=0

for base in "${SOURCES[@]}"; do
  src="${SRC_DIR}/${base}"
  dbg_line "PROCESS src=${base}"

  # Ziele einsammeln
  mapfile -t DESTS < <(extract_dests "${src}" | trim)
  if ((${#DESTS[@]}==0)); then
    echo "⚠️ ${base}: keine @dest-Zeilen gefunden"
    dbg_json "no_dest" "\"src\":\"${base//\"/\\\"}\""
    ((total_nodest++))
    continue
  fi

  # Auflösen + entfusseln
  DESTS_ABS=()
  for d in "${DESTS[@]}"; do
    d="${d%%*/}"                                      # alles nach letztem "*/" kappen (falls vorhanden)
    d="$(printf '%s' "$d" | sed 's/[[:space:]]*$//')" # rtrim
    abs="$(resolve_path "$d")"
    DESTS_ABS+=( "${abs}" )
    dbg_json "dest_resolved" "\"src\":\"${base//\"/\\\"}\",\"dest\":\"${d//\"/\\\"}\",\"dest_abs\":\"${abs//\"/\\\"}\""
  done

  # Kopieren/Abgleichen je Target
  created=0; updated=0; identical=0; errors=0
  for dest in "${DESTS_ABS[@]}"; do
    dest_dir="$(dirname -- "$dest")"
    if [ ! -d "${dest_dir}" ]; then
      if [ "${ALLOW_CREATE}" -eq 1 ]; then
        if [ "${DRY_RUN}" -eq 1 ]; then
          echo "→ CREATE(DIR) ${dest_dir}"
        else
          if ! mkdir -p -- "${dest_dir}"; then
            echo "❌ mkdir failed: ${dest_dir}"
            ((errors++)); ((total_errors++))
            continue
          fi
        fi
      else
        echo "→ SKIP(CREATE) ${dest}  (Policy: default no-create; use --allow-create)"
        ((total_nodest++))
        continue
      fi
    fi

    if [ -f "${dest}" ]; then
      if same_file "${src}" "${dest}"; then
        echo "→ SKIP    ${dest} (identisch)"
        ((identical++)); ((total_identical++))
      else
        if [ "${DRY_RUN}" -eq 1 ]; then
          echo "→ UPDATE  ${dest}"
          ((updated++)); ((total_updated++))
        else
          ts="$(date -u +%Y%m%dT%H%M%SZ)"
          cp -- "${dest}" "${dest}.bak.${ts}" 2>/dev/null || true
          if cp -- "${src}" "${dest}"; then
            echo "→ UPDATE  ${dest}"
            ((updated++)); ((total_updated++))
          else
            echo "❌ copy failed: ${src} → ${dest}"
            ((errors++)); ((total_errors++))
          fi
        fi
      fi
    else
      if [ "${ALLOW_CREATE}" -eq 1 ]; then
        if [ "${DRY_RUN}" -eq 1 ]; then
          echo "→ CREATE  ${dest}"
          ((created++)); ((total_created++))
        else
          if cp -- "${src}" "${dest}"; then
            echo "→ CREATE  ${dest}"
            ((created++)); ((total_created++))
          else
            echo "❌ copy failed: ${src} → ${dest}"
            ((errors++)); ((total_errors++))
          fi
        fi
      else
        echo "→ SKIP(CREATE) ${dest}  (Policy: default no-create; use --allow-create)"
        ((total_nodest++))
      fi
    fi
  done

  # Per-File Logeintrag
  if [ "${LC_OK}" -eq 1 ]; then
    msg="$(fmt_count created "${created}"); msg+='; '; msg+=$(fmt_count updated "${updated}"); msg+='; '; msg+=$(fmt_count identical "${identical}")"
    notiz="$(format_targets_for_notiz "${DESTS_ABS[@]}")"
    set +u
    lc_log_event_all INFO "sync" "file" "\`${base}\`" "✅" 0 0 "${notiz}" \
      "wiki, sync, css, stylesheet$( [ "${DEBUG}" = "TRACE" ] && echo ", trace" )$( [ "${ALLOW_CREATE}" -eq 1 ] && echo ", allow-create" )" \
      "${msg}"
    set -u
  fi
done

# ---------------- Summary ----------------
echo "OK: created ${total_created}, updated ${total_updated}, identisch ${total_identical}, nodest ${total_nodest}, errors ${total_errors}"

if [ "${LC_OK}" -eq 1 ]; then
  sum_msg="plan_create=${total_created}; plan_update=${total_updated}; identical=${total_identical}; pruned=0; nodest=${total_nodest}; errors=${total_errors}"
  set +u
  lc_log_event_all INFO "sync" "apply" "" "✅" 0 0 "Sources: ${SRC_COUNT}" \
    "wiki, sync, shell-script, summary$( [ "${DEBUG}" = "TRACE" ] && echo ", trace" )$( [ "${ALLOW_CREATE}" -eq 1 ] && echo ", allow-create" )" \
    "${sum_msg}"
  [ "${LC_HAS_FINALIZE}" -eq 1 ] && lc_finalize
  set -u
fi

# ---------------- Optional: Render HTML ----------------
if [ "${RENDER_HTML}" -eq 1 ]; then
  if command -v log_render_html.sh >/dev/null 2>&1; then
    log_render_html.sh >/dev/null 2>&1 || true
  fi
fi

exit 0
