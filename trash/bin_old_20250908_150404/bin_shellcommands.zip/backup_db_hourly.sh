#!/usr/bin/env bash
# backup_db_hourly.sh — stündlicher PG-Dump (24 Rotationen) nach <project>/.backups/db/hourly
# Version: v0.2.2
set -euo pipefail

DRY=0; FORMAT="md"
VERSION="v0.2.2"

usage(){ cat <<'HLP'
backup_db_hourly — stündlicher PostgreSQL Dump mit Rotation (24)
USAGE
  backup_db_hourly [--dry-run] [--format md|txt] [--help] [--version]
HLP
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY=1; shift;;
    --format) FORMAT="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    --version) echo "$VERSION"; exit 0;;
    *) echo "Unbekannter Parameter: $1"; usage; exit 1;;
  esac
done

# Gatekeeper & Tools
[[ -f .env ]] || { echo "Fehler: .env fehlt (im Projekt-Root ausführen)"; exit 2; }
command -v pg_dump >/dev/null || { echo "Fehler: pg_dump nicht gefunden"; exit 3; }

# Logger optional laden + Fallbacks bereitstellen
if [[ -f "$HOME/bin/proj_logger.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/bin/proj_logger.sh"
fi
if ! type -t log_init >/dev/null 2>&1; then
  log_init(){ :; }
  log_section(){ :; }
  log_info(){ echo "[INFO] $*"; }
  log_warn(){ echo "[WARN] $*" >&2; }
  log_error(){ echo "[ERROR] $*" >&2; }
  log_file(){ :; }
fi

export PROJ_LOG_FORMAT="${FORMAT}"
export PROJ_LOG_PREFIX="$(basename "$PWD")|backup_db_hourly"
log_init 2>/dev/null || true
log_section "DB Hourly"

# Robustes .env-Parsing (Quotes/CR/Inline-Kommentare)
dotenv_get() {
  local key="$1"
  sed -nE "s/^[[:space:]]*${key}[[:space:]]*=[[:space:]]*['\"]?([^\"'#]*)['\"]?.*$/\1/p" .env \
    | tail -n1 | tr -d '\r'
}

DB_HOST="$(dotenv_get DB_HOST)"
DB_PORT="$(dotenv_get DB_PORT)"
DB_DATABASE="$(dotenv_get DB_DATABASE)"
DB_USERNAME="$(dotenv_get DB_USERNAME)"
DB_PASSWORD="$(dotenv_get DB_PASSWORD)"

[[ -n "$DB_HOST" && -n "$DB_PORT" && -n "$DB_DATABASE" && -n "$DB_USERNAME" ]] || {
  log_error "DB-Konfiguration unvollständig (.env)"; exit 4;
}
if [[ -z "$DB_PASSWORD" ]]; then
  log_warn "DB_PASSWORD leer – Auth muss dann per .pgpass/peer funktionieren."
fi

# Pfade
outdir=".backups/db/hourly"; mkdir -p "$outdir"
ts="$(date +%Y%m%d_%H%M%S)"
dump="${outdir}/${DB_DATABASE}_${ts}.sql.gz"
sha="${dump}.sha256"

log_info "Target: ${dump}"
log_info "Conn: host=${DB_HOST} port=${DB_PORT} db=${DB_DATABASE} user=${DB_USERNAME} pass=***"

if (( DRY )); then
  log_dry "PGPASSWORD=*** pg_dump -h '${DB_HOST}' -p '${DB_PORT}' -U '${DB_USERNAME}' '${DB_DATABASE}' | gzip -9 > '${dump}'"
  log_dry "sha256sum '${dump}' > '${sha}'"
else
  export PGPASSWORD="${DB_PASSWORD}"
  if pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USERNAME" "$DB_DATABASE" | gzip -9 > "$dump"; then
    # Checksumme nur, wenn Tool vorhanden; Fehlschlag ignorieren
    if command -v sha256sum >/dev/null 2>&1; then
      sha256sum "$dump" > "$sha" || true
    fi
    log_info "OK: Dump geschrieben"
  else
    log_error "Dump fehlgeschlagen (Credentials/pg_hba prüfen)"
    exit 10
  fi
fi

# Rotation: keep last 24 (Fehler hier nie hart)
log_section "Rotation"
count=0
set +e
ls -1t "${outdir}/"*.sql.gz 2>/dev/null | while read -r f; do
  count=$((count+1))
  if (( count > 24 )); then
    if (( DRY )); then
      log_dry "rm -f '${f}' '${f}.sha256'"
    else
      rm -f -- "$f" "$f.sha256" 2>/dev/null
    fi
  fi
done
set -e
log_info "Rotation: behalten=24, gesehen=${count}"

# Logfile-Pfad sauber ausgeben (ohne &&/||-Akrobatik)
lf=""
if type -t log_file >/dev/null 2>&1; then
  lf="$(log_file || true)"
fi
printf "Logfile: %s\n" "${lf}"

exit 0
